<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/gif" href="<?php echo e(asset('roket.gif')); ?>">
<link rel="shortcut icon" type="image/gif" href="<?php echo e(asset('roket.gif')); ?>">
    <title><?php echo e(config('app.name')); ?> - Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">

    <div class="flex flex-col md:flex-row w-full max-w-6xl max-h-[90vh] bg-white rounded-xl shadow-xl overflow-hidden">

        <!-- Hanya scroll di mobile, hilang di md+ -->
        <div class="flex-1 overflow-y-auto md:overflow-y-visible">
            <?php echo e($slot); ?>

        </div>

    </div>

</body>

</html>
<?php /**PATH E:\projek pemrograman\laravel\shortener\resources\views/layouts/guest.blade.php ENDPATH**/ ?>