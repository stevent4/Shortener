import './bootstrap';

import Alpine from 'alpinejs';
import "../css/app.css";

window.Alpine = Alpine;

Alpine.start();
