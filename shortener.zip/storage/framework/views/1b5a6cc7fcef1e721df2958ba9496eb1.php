

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8 px-4">

    <h2 class="text-2xl font-bold mb-6 text-gray-800">Detail Short Link</h2>

    <div class="bg-white shadow-md rounded-xl p-6 space-y-4">

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Pembuat:</span>
            <span class="text-gray-800"><?php echo e($link->user->name); ?> (ID: <?php echo e($link->user->id); ?>)</span>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Short URL:</span>
            <a href="<?php echo e(url($link->short_code)); ?>" class="text-blue-600 hover:underline" target="_blank">
                <?php echo e(url($link->short_code)); ?>

            </a>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Original URL:</span>
            <span class="text-gray-700 break-all"><?php echo e($link->original_url); ?></span>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Status Aktif:</span>
            <span class="<?php echo e($link->is_active ? 'text-green-600 font-semibold' : 'text-red-600 font-semibold'); ?>">
                <?php echo e($link->is_active ? 'Aktif' : 'Nonaktif'); ?>

            </span>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Private:</span>
            <span class="<?php echo e($link->is_private ? 'text-blue-600 font-semibold' : 'text-gray-600'); ?>">
                <?php echo e($link->is_private ? 'Ya' : 'Tidak'); ?>

            </span>
        </div>

        <?php if($link->is_private): ?>
            <div class="flex flex-col sm:flex-row sm:justify-between">
                <span class="font-medium text-gray-700">Password:</span>
                <span class="text-gray-500">Terenkripsi (tidak dapat ditampilkan)</span>
            </div>
        <?php endif; ?>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Kadaluarsa:</span>
            <span class="text-gray-800">
                <?php if($link->expired_at): ?>
                    <?php echo e($link->expired_at->format('d M Y H:i')); ?>

                    <?php if($link->expired_at->isPast()): ?>
                        <span class="text-red-600 font-semibold">(Sudah Expired)</span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="text-gray-500">Tidak ada</span>
                <?php endif; ?>
            </span>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Total Klik:</span>
            <span class="text-gray-800"><?php echo e($link->clicks); ?></span>
        </div>

        <div class="flex flex-col sm:flex-row sm:justify-between">
            <span class="font-medium text-gray-700">Dibuat Pada:</span>
            <span class="text-gray-800"><?php echo e($link->created_at->format('d M Y H:i')); ?></span>
        </div>

        <div class="mt-6">
            <a href="<?php echo e(url()->previous()); ?>" class="text-blue-600 hover:underline">← Kembali</a>
        </div>
    </div>

    
    <h3 class="text-xl font-semibold mt-10 mb-4 text-gray-800">Riwayat Klik</h3>

    <div class="bg-white shadow-md rounded-xl p-4">
        <?php if($clicks->count() == 0): ?>
            <p class="text-gray-500">Belum ada klik.</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IP</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User Agent</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Referrer</th>
                            <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Waktu</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 transition-colors duration-200">
                                <td class="px-4 py-2 text-gray-700"><?php echo e($c->ip_address); ?></td>
                                <td class="px-4 py-2 text-gray-700 break-all"><?php echo e($c->user_agent); ?></td>
                                <td class="px-4 py-2 text-gray-700"><?php echo e($c->referrer ?? '-'); ?></td>
                                <td class="px-4 py-2 text-gray-500"><?php echo e($c->created_at->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                <?php echo e($clicks->links()); ?>

            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Details'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\projek pemrograman\laravel\shortener\resources\views/admin/links/show.blade.php ENDPATH**/ ?>