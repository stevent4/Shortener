<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/gif" href="<?php echo e(asset('roket.gif')); ?>">
<link rel="shortcut icon" type="image/gif" href="<?php echo e(asset('roket.gif')); ?>">
    <title><?php echo e(config('app.name')); ?> | <?php echo e($title ?? ''); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>

    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo e($title ?? 'My Shortener'); ?>">
    <meta property="og:description" content="<?php echo e($description ?? 'Aplikasi Short Link aman & fun!'); ?>">
    <meta property="og:image" content="<?php echo e($image ?? asset('img.png')); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    
</head>

<body class="bg-gradient-to-b from-blue-50 to-purple-50 min-h-screen flex flex-col font-sans">

    
    <nav class="bg-white shadow-md">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <a href="<?php echo e(route('dashboard')); ?>" class="text-2xl font-bold text-purple-600 hover:text-purple-400 flex items-center space-x-2">
            <span>🚀</span>
            <span>Shortener</span>
        </a>

        
        <div class="md:hidden">
            <button id="hamburger" class="text-gray-700 focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2"
                    viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 6h16M4 12h16M4 18h16"></path>
                </svg>
            </button>
        </div>

        
        <div id="menu" class="hidden md:flex md:items-center md:space-x-4 relative">
            <ul class="flex flex-col md:flex-row md:space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>" class="block px-2 py-1 text-gray-700 hover:text-purple-600 transition">Dashboard</a>
                    </li>

                    <?php if(auth()->user()->is_admin): ?>
                        <li class="relative">
                            <button id="admin-dropdown-btn" class="block px-2 py-1 text-gray-700 hover:text-purple-600 transition focus:outline-none">
                                Admin ▾
                            </button>
                            
                            <div id="admin-dropdown" class="hidden absolute top-full left-0 mt-1 w-48 bg-white shadow-lg rounded-md z-50">
                                <a href="<?php echo e(route('admin.links.index')); ?>" class="block px-4 py-2 text-gray-700 hover:bg-purple-100 transition">Semua Link</a>
                                <a href="<?php echo e(route('admin.users.index')); ?>" class="block px-4 py-2 text-gray-700 hover:bg-purple-100 transition">Users</a>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>

            <div class="mt-2 md:mt-0 md:ml-4">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="block px-4 py-2 border border-gray-300 rounded hover:bg-purple-100 transition">
                        Login
                    </a>
                <?php else: ?>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="block px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition">
                            Logout
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<script>
    // Hamburger toggle
    const hamburger = document.getElementById('hamburger');
    const menu = document.getElementById('menu');
    hamburger.addEventListener('click', () => {
        menu.classList.toggle('hidden');
    });

    // Admin dropdown toggle
    const adminBtn = document.getElementById('admin-dropdown-btn');
    const adminDropdown = document.getElementById('admin-dropdown');

    if (adminBtn) {
        adminBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            adminDropdown.classList.toggle('hidden');
        });

        // Close dropdown if clicked outside
        document.addEventListener('click', () => {
            adminDropdown.classList.add('hidden');
        });
    }
</script>


    
    <div class="container mx-auto px-4 mt-4">
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-300 text-green-700 p-3 rounded mb-4 animate-fadeIn">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-300 text-red-700 p-3 rounded mb-4 animate-fadeIn">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
    </div>

    
    <main class="container mx-auto px-4 flex-1 mt-4">
        <div class="bg-white shadow-lg rounded-xl p-6 animate-fadeIn">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    
    <footer class="bg-white shadow-inner mt-auto py-4">
        <div class="container mx-auto px-4 text-center text-gray-500 text-sm">
            &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. Made with 💜 and Tailwind!
        </div>
    </footer>

    </body>
</html>
<?php /**PATH E:\projek pemrograman\laravel\shortener\resources\views/layouts/app.blade.php ENDPATH**/ ?>