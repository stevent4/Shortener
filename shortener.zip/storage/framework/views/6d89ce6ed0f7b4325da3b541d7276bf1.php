

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8 px-4">
    <h1 class="text-2xl font-bold mb-6 text-gray-800">Admin - Users</h1>

    <div class="bg-white shadow-md rounded-xl overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Links</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Admin</th>
                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200">
                    <td class="px-4 py-2 text-gray-700"><?php echo e($user->name); ?></td>
                    <td class="px-4 py-2 text-gray-700 break-all"><?php echo e($user->email); ?></td>
                    <td class="px-4 py-2 text-gray-700"><?php echo e($user->short_links_count); ?></td>
                    <td class="px-4 py-2">
                        <span class="<?php echo e($user->is_admin ? 'text-green-600 font-semibold' : 'text-gray-500'); ?>">
                            <?php echo e($user->is_admin ? 'Yes' : 'No'); ?>

                        </span>
                    </td>
                    <td class="px-4 py-2 flex flex-wrap gap-2">
                        <form method="POST" action="<?php echo e(route('admin.users.toggleAdmin', $user)); ?>" class="inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button class="px-2 py-1 text-sm rounded-md <?php echo e($user->is_admin ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200' : 'bg-blue-100 text-blue-800 hover:bg-blue-200'); ?> transition">
                                <?php echo e($user->is_admin ? 'Revoke' : 'Make Admin'); ?>

                            </button>
                        </form>

                        <form method="POST" action="<?php echo e(route('admin.users.destroy', $user)); ?>" class="inline" onsubmit="return confirm('Hapus user?');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="px-2 py-1 text-sm bg-red-100 text-red-700 rounded-md hover:bg-red-200 transition">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Users'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\projek pemrograman\laravel\shortener\resources\views/admin/users/index.blade.php ENDPATH**/ ?>