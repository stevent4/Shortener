

<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8 px-4">
    <h3 class="text-2xl font-semibold mb-6 text-gray-800">Semua Link</h3>

    <div class="bg-white shadow-md rounded-xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pembuat</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Short</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Original</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Expired</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dibuat</th>
                        <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>

                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition-colors duration-200">
                            <td class="px-4 py-3 text-gray-700"><?php echo e($loop->iteration); ?></td>
                            <td class="px-4 py-3 text-gray-700"><?php echo e($link->user->name ?? '-'); ?></td>
                            <td class="px-4 py-3 text-blue-600 font-medium hover:underline">
                                <a href="<?php echo e(url($link->short_code)); ?>" target="_blank"><?php echo e(url($link->short_code)); ?></a>
                            </td>
                            <td class="px-4 py-3 text-gray-700 truncate max-w-xs"><?php echo e($link->original_url); ?></td>
                            <td class="px-4 py-3 text-gray-500"><?php echo e($link->expired_at ? $link->expired_at->translatedFormat('d F Y') : '-'); ?></td>
                            <td class="px-4 py-3 text-gray-500"><?php echo e($link->created_at->format('d M Y H:i')); ?></td>
                            <td class="px-4 py-3 flex space-x-2">
                                <a href="<?php echo e(route('admin.links.show', $link->id)); ?>" 
                                   class="px-3 py-1 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600 transition">
                                    Detail
                                </a>

                                <form action="<?php echo e(route('admin.links.destroy', $link->id)); ?>" 
                                      method="POST"
                                      onsubmit="return confirm('Apakah yakin ingin menghapus link ini?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="px-3 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="px-4 py-6 text-center text-gray-400">Belum ada link dibuat</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="px-4 py-3 bg-gray-50 border-t border-gray-200">
            <?php echo e($links->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'All Links'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\projek pemrograman\laravel\shortener\resources\views/admin/links/index.blade.php ENDPATH**/ ?>