<x-app-layout :title="'Link Tidak Ditemukan'">

<div class="alert alert-danger">
    <h4>Link tidak ditemukan atau sudah dihapus.</h4>
</div>

<a href="{{ route('dashboard') }}" class="btn btn-primary">Kembali</a>

</x-app-layout>
